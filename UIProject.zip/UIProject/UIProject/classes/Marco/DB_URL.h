//
//  DB_URL.h
//  UIProject
//
//  Created by lanou3g on 16/6/22.
//  Copyright © 2016年 王晓南. All rights reserved.
//

#ifndef DB_URL_h
#define DB_URL_h

//BASEURL
#define DB_BASE_URL @"http://au.umeng.com/check_config_update"

//POST
#define DB_DETAIL @"?content=%7B%22appkey%22%3A%225424c4fbfd98c58f0901fc47%22%2C%22channel%22%3A%22App%20Store%22%2C%22ad_request%22%3A1%2C%22time%22%3A%2219%3A03%3A41%22%2C%22package%22%3A%22com.lighting.BabyFoodAll%22%2C%22type%22%3A%22online_config%22%2C%22sdk_type%22%3A%22iOS%22%2C%22sdk_version%22%3A%223.1.6%22%7D"



#endif /* DB_URL_h */
