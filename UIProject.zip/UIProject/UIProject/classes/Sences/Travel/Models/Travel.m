//
//  Travel.m
//  UIProject
//
//  Created by lanou3g on 16/6/23.
//  Copyright © 2016年 王晓南. All rights reserved.
//

#import "Travel.h"

@implementation Travel

- (void)setValue:(id)value forUndefinedKey:(NSString *)key {
    
}

@end
